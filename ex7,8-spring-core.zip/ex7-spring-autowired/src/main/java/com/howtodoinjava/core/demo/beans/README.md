# Related tutorials

1. [Spring beans using annotation configuration](https://howtodoinjava.com/spring5/core/spring-bean-java-config/)
2. [Spring beans using xml configuration](https://howtodoinjava.com/spring5/core/spring-bean-xml-config/)
3. [Spring lazy loading](https://howtodoinjava.com/spring5/core/spring-bean-eager-vs-lazy-init/)
4. [Spring stereotype annotations](https://howtodoinjava.com/spring-core/stereotype-annotations/)