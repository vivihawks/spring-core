# Related tutorials

1. [Spring � Send email with JavaMailSender](https://howtodoinjava.com/spring-core/send-email-with-spring-javamailsenderimpl-example/)