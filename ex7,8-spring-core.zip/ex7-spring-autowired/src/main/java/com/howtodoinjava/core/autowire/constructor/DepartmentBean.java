package com.howtodoinjava.core.autowire.constructor;

public class DepartmentBean{
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
