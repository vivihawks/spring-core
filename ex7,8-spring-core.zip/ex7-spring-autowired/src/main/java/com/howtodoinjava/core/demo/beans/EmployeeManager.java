package com.howtodoinjava.core.demo.beans;

interface EmployeeManager {
	public Employee create();
}
