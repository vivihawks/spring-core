package net.javaguides.spring.scope;

public interface MessageService {

	String getMessage();
	
	void setMessage(String message);
}
