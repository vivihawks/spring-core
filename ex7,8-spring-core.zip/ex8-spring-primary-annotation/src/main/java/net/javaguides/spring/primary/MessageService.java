package net.javaguides.spring.primary;

public interface MessageService {
	public void sendMsg();	
}
