package net.javaguides.spring.lazy;

public class FirstBean {

	public FirstBean() {
		System.out.println("Inside FirstBean Constuctor");
	}

	public void test() {
		System.out.println("Method of FirstBean Class");
	}
}
