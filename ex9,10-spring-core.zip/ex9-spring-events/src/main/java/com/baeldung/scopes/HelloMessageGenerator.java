package com.baeldung.scopes;

public class HelloMessageGenerator {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

}
