package com.baeldung.sample;

public class Bar {

}
