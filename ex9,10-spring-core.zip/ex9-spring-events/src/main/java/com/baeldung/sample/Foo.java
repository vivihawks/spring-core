package com.baeldung.sample;

public class Foo {

}
