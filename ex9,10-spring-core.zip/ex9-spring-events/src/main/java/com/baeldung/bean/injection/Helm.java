package com.baeldung.bean.injection;

public class Helm {

    private String brandOfHelm = "HelmBrand";

    public String getBrandOfHelm() {
        return brandOfHelm;
    }

    public void setBrandOfHelm(String brandOfHelm) {
        this.brandOfHelm = brandOfHelm;
    }
}
