package com.baeldung.order;

public interface Rating {
    
    int getRating();
}
