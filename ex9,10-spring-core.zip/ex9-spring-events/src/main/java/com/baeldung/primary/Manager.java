package com.baeldung.primary;

/**
 * Created by Gebruiker on 7/19/2018.
 */
public interface Manager {
    String getManagerName();
}
