package com.baeldung.profiles;

public interface DatasourceConfig {
    void setup();
}
