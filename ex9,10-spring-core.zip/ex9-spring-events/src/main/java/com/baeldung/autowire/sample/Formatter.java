package com.baeldung.autowire.sample;

public interface Formatter {

    String format();

}
