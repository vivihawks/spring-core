package com.baeldung.autowire.sample;

public class FooDAO {

}
