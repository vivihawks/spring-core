package com.javadevsguide.springframework.aop.aspect;

public @interface Loggable {

}
