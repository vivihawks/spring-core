package com.javadevsguide.springframework.service;

public interface MessageProcessor {
	public void processMsg(String message);
}
