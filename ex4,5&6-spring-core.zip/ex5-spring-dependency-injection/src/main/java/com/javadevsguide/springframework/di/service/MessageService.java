package com.javadevsguide.springframework.di.service;

public interface MessageService {
	public void sendMsg(String message);
}
