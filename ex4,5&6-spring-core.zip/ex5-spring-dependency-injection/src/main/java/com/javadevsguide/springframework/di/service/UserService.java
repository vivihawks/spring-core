package com.javadevsguide.springframework.di.service;

public interface UserService {
	public void processMsg(String message);
}
